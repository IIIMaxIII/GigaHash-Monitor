# migrate_db_v3_to_v4.py
"""
Миграция БД GigaHash Monitor со схемы 3.x на 4.0.

Что меняется:
- balance, paid: REAL (NOCK) → INTEGER (nicks)
- zk_hashrate: REAL (proof/s) → INTEGER (proof/s)
- share_acceptance: REAL (%) → INTEGER (% × 100)
- nock_price: REAL (USDT) → INTEGER (µUSDT)
- estimated_earnings: REAL (USDT/день) → INTEGER (центы)
- workers[]: строки → числа
- payouts[]: строки → числа
- hourly_stats: REAL (NOCK) → INTEGER (nicks)

Скрипт САМ заменяет старую БД на новую.
Бэкап создаётся ДО замены — если что-то упадёт, есть откат.
"""

import os
import sys
import sqlite3
import shutil
import json
import re
from datetime import datetime


# =====================================================================
# Константы
# =====================================================================
NICKS_PER_NOCK = 65_536
USDT_E6 = 1_000_000
PERCENT_X100 = 100
CENTS_X100 = 100


# =====================================================================
# Пути
# =====================================================================
APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, 'data')
OLD_DB_PATH = os.path.join(DATA_DIR, 'history.db')
NEW_DB_PATH = os.path.join(DATA_DIR, 'history_v4.db')


# =====================================================================
# Утилиты
# =====================================================================
def backup_db():
    """Создаёт бэкап старой БД с timestamp."""
    if not os.path.exists(OLD_DB_PATH):
        print(f"❌ Старая БД не найдена: {OLD_DB_PATH}")
        return None

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup = f"{OLD_DB_PATH}.backup_v3_{timestamp}"
    shutil.copy2(OLD_DB_PATH, backup)
    size_mb = os.path.getsize(backup) / 1024 / 1024
    print(f"✅ Бэкап старой БД: {backup} ({size_mb:.2f} MB)")
    return backup


def parse_hashrate_from_string(s):
    """'48,671 proof/s' → 48671 (INTEGER)"""
    if s is None:
        return 0
    if isinstance(s, (int, float)):
        return int(round(s))
    m = re.search(r'([\d\s,\.]+)', str(s))
    if not m:
        return 0
    num_str = m.group(1).replace(' ', '').replace(',', '')
    try:
        return int(round(float(num_str)))
    except ValueError:
        return 0


def parse_usd_from_string(s):
    """'1.28 usdt' → 128 (центы, INTEGER)"""
    if s is None:
        return 0
    if isinstance(s, (int, float)):
        return int(round(s * CENTS_X100))
    m = re.search(r'([\d\.\,]+)', str(s))
    if not m:
        return 0
    num_str = m.group(1).replace(',', '.')
    try:
        return int(round(float(num_str) * CENTS_X100))
    except ValueError:
        return 0


def parse_gpus_from_string(s):
    """'8/8' → (8, 8)"""
    if s is None:
        return (0, 0)
    if isinstance(s, str) and '/' in s:
        parts = s.split('/')
        try:
            return (int(parts[0]), int(parts[1]))
        except ValueError:
            return (0, 0)
    return (0, 0)


def parse_uptime_from_string(s):
    """'10h' → 10 (часы)"""
    if s is None:
        return 0
    if isinstance(s, (int, float)):
        return int(s)
    m = re.search(r'(\d+)', str(s))
    if not m:
        return 0
    return int(m.group(1))


def nock_to_nicks(nock):
    """71.305431 NOCK → 4672435 nicks"""
    if nock is None:
        return 0
    try:
        return int(round(float(nock) * NICKS_PER_NOCK))
    except (ValueError, TypeError):
        return 0


def usdt_to_e6(usdt):
    """0.04137407 USDT → 41374 µUSDT"""
    if usdt is None:
        return 0
    try:
        return int(round(float(usdt) * USDT_E6))
    except (ValueError, TypeError):
        return 0


def percent_to_x100(pct):
    """99.44 % → 9944 (% × 100)"""
    if pct is None:
        return 0
    try:
        return int(round(float(pct) * PERCENT_X100))
    except (ValueError, TypeError):
        return 0


def usd_to_cents(usd):
    """48.24 USDT → 4824 центов"""
    if usd is None:
        return 0
    try:
        return int(round(float(usd) * CENTS_X100))
    except (ValueError, TypeError):
        return 0


# =====================================================================
# Создание новой БД (схема 4.0)
# =====================================================================
def create_new_db():
    if os.path.exists(NEW_DB_PATH):
        os.remove(NEW_DB_PATH)

    conn = sqlite3.connect(NEW_DB_PATH)
    c = conn.cursor()

    c.execute('''
        CREATE TABLE miner_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp INTEGER NOT NULL,
            address TEXT NOT NULL,
            balance_nicks INTEGER,
            paid_nicks INTEGER,
            workers_online INTEGER,
            zk_hashrate INTEGER,
            share_acceptance INTEGER,
            nock_price_usdt_e6 INTEGER,
            estimated_earnings_cents INTEGER,
            workers TEXT,
            payouts TEXT
        )
    ''')

    c.execute('''
        CREATE TABLE miner_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version TEXT NOT NULL UNIQUE,
            updated INTEGER,
            last_seen INTEGER NOT NULL
        )
    ''')

    c.execute('''
        CREATE TABLE hourly_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hour INTEGER NOT NULL,
            address TEXT NOT NULL,
            balance_change_nicks INTEGER,
            cumulative_from_hour_start_nicks INTEGER,
            UNIQUE(hour, address)
        )
    ''')

    c.execute('CREATE INDEX idx_history_addr_ts ON miner_history(address, timestamp)')
    c.execute('CREATE INDEX idx_hourly_addr_hour ON hourly_stats(address, hour)')

    conn.commit()
    conn.close()
    print("✅ Создана новая БД (схема 4.0)")


# =====================================================================
# Проверка схемы старой БД
# =====================================================================
def detect_old_schema():
    if not os.path.exists(OLD_DB_PATH):
        return None

    conn = sqlite3.connect(OLD_DB_PATH)
    c = conn.cursor()

    try:
        c.execute("PRAGMA table_info(miner_history)")
        columns = [col[1] for col in c.fetchall()]
    except sqlite3.Error as e:
        print(f"❌ Ошибка чтения схемы: {e}")
        conn.close()
        return None

    conn.close()

    if not columns:
        return None

    return columns


# =====================================================================
# Миграция miner_history
# =====================================================================
def migrate_miner_history(old_conn, new_conn):
    print("\n📊 Миграция miner_history...")

    old_c = old_conn.cursor()
    new_c = new_conn.cursor()

    old_c.execute("PRAGMA table_info(miner_history)")
    old_columns = [col[1] for col in old_c.fetchall()]
    print(f"   Старые колонки: {old_columns}")

    has_old_naming = 'balance' in old_columns and 'nock_price' in old_columns
    has_new_naming = 'balance_nicks' in old_columns

    if has_new_naming:
        print("   ⚠️  БД уже в новом формате — пропуск miner_history")
        return 0

    if not has_old_naming:
        print(f"   ❌ Не найдены нужные колонки — пропуск")
        return 0

    old_c.execute('''
        SELECT id, timestamp, address, balance, paid, workers_online,
               zk_hashrate, share_acceptance, nock_price, estimated_earnings,
               workers, payouts
        FROM miner_history
        ORDER BY id ASC
    ''')
    rows = old_c.fetchall()
    print(f"   Найдено записей: {len(rows)}")

    migrated = 0

    for row in rows:
        (row_id, timestamp, address, balance, paid, workers_online,
         zk_hashrate, share_acceptance, nock_price, estimated_earnings,
         workers_json, payouts_json) = row

        balance_nicks = nock_to_nicks(balance)
        paid_nicks = nock_to_nicks(paid)
        workers_online_int = int(workers_online or 0)
        zk_hashrate_int = int(round(float(zk_hashrate or 0)))
        share_acceptance_x100 = percent_to_x100(share_acceptance)
        nock_price_e6 = usdt_to_e6(nock_price)
        estimated_cents = usd_to_cents(estimated_earnings)

        # === Workers JSON ===
        workers_new = []
        if workers_json:
            try:
                workers = json.loads(workers_json)
                for w in workers:
                    w_new = {
                        "name": w.get("name", "?"),
                        "id": w.get("id", ""),
                        "hashrate": parse_hashrate_from_string(w.get("hashrate")),
                        "usd_per_day_cents": parse_usd_from_string(w.get("usd_per_day")),
                        "status": w.get("status", "ONLINE"),
                        "miner_version": w.get("miner_version"),
                    }

                    if "gpus" in w:
                        on, total = parse_gpus_from_string(w["gpus"])
                        w_new["gpus_online"] = on
                        w_new["gpus_total"] = total

                    if "uptime" in w:
                        w_new["uptime_hours"] = parse_uptime_from_string(w["uptime"])
                    elif "uptime_hours" in w:
                        w_new["uptime_hours"] = int(w["uptime_hours"])

                    workers_new.append(w_new)
            except Exception as e:
                print(f"   ⚠️  Ошибка парсинга workers для id={row_id}: {e}")

        # === Payouts JSON ===
        payouts_new = []
        if payouts_json:
            try:
                payouts = json.loads(payouts_json)
                for p in payouts:
                    p_new = {
                        "batch": p.get("batch", ""),
                        "status": p.get("status", "?"),
                        "amount_nicks": nock_to_nicks(p.get("amount")),
                        "fee_nicks": nock_to_nicks(p.get("fee")),
                        "transaction": p.get("transaction", ""),
                        "created_at": p.get("created_at"),
                        "updated_at": p.get("updated_at"),
                    }
                    payouts_new.append(p_new)
            except Exception as e:
                print(f"   ⚠️  Ошибка парсинга payouts для id={row_id}: {e}")

        new_c.execute('''
            INSERT INTO miner_history (
                id, timestamp, address, balance_nicks, paid_nicks,
                workers_online, zk_hashrate, share_acceptance,
                nock_price_usdt_e6, estimated_earnings_cents,
                workers, payouts
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            row_id,
            int(timestamp) if timestamp else 0,
            address,
            balance_nicks,
            paid_nicks,
            workers_online_int,
            zk_hashrate_int,
            share_acceptance_x100,
            nock_price_e6,
            estimated_cents,
            json.dumps(workers_new, ensure_ascii=False),
            json.dumps(payouts_new, ensure_ascii=False),
        ))

        migrated += 1

    new_conn.commit()
    print(f"   ✅ Мигрировано: {migrated}")
    return migrated


# =====================================================================
# Миграция miner_versions
# =====================================================================
def migrate_miner_versions(old_conn, new_conn):
    print("\n📊 Миграция miner_versions...")

    old_c = old_conn.cursor()
    new_c = new_conn.cursor()

    try:
        old_c.execute('''
            SELECT version, updated, last_seen
            FROM miner_versions
        ''')
        rows = old_c.fetchall()
    except sqlite3.Error as e:
        print(f"   ⚠️  Ошибка чтения: {e}")
        return 0

    print(f"   Найдено записей: {len(rows)}")

    migrated = 0
    for version, updated, last_seen in rows:
        new_c.execute('''
            INSERT OR IGNORE INTO miner_versions (version, updated, last_seen)
            VALUES (?, ?, ?)
        ''', (
            version,
            int(updated) if updated else None,
            int(last_seen) if last_seen else 0,
        ))
        migrated += 1

    new_conn.commit()
    print(f"   ✅ Мигрировано: {migrated}")
    return migrated


# =====================================================================
# Миграция hourly_stats
# =====================================================================
def migrate_hourly_stats(old_conn, new_conn):
    print("\n📊 Миграция hourly_stats...")

    old_c = old_conn.cursor()
    new_c = new_conn.cursor()

    try:
        old_c.execute("PRAGMA table_info(hourly_stats)")
        columns = [col[1] for col in old_c.fetchall()]
    except sqlite3.Error as e:
        print(f"   ⚠️  Ошибка чтения схемы: {e}")
        return 0

    if 'balance_change_nicks' in columns:
        print("   ⚠️  Уже в новом формате — пропуск")
        return 0

    try:
        old_c.execute('''
            SELECT hour, address, balance_change, cumulative_from_hour_start
            FROM hourly_stats
            ORDER BY hour ASC
        ''')
        rows = old_c.fetchall()
    except sqlite3.Error as e:
        print(f"   ⚠️  Ошибка чтения: {e}")
        return 0

    print(f"   Найдено записей: {len(rows)}")

    migrated = 0
    for hour, address, balance_change, cumulative in rows:
        new_c.execute('''
            INSERT OR REPLACE INTO hourly_stats
                (hour, address, balance_change_nicks, cumulative_from_hour_start_nicks)
            VALUES (?, ?, ?, ?)
        ''', (
            int(hour) if hour else 0,
            address,
            nock_to_nicks(balance_change),
            nock_to_nicks(cumulative),
        ))
        migrated += 1

    new_conn.commit()
    print(f"   ✅ Мигрировано: {migrated}")
    return migrated


# =====================================================================
# Замена старой БД на новую
# =====================================================================
def replace_old_db():
    """Заменяет старую БД на новую. Старая УЖЕ в бэкапе."""
    print("\n🔄 Замена старой БД на новую...")

    try:
        # Удаляем старую (бэкап уже есть)
        if os.path.exists(OLD_DB_PATH):
            os.remove(OLD_DB_PATH)
            print(f"   🗑️  Удалена старая БД")

        # Переименовываем новую
        os.rename(NEW_DB_PATH, OLD_DB_PATH)
        print(f"   ✅ Новая БД перемещена на место старой")

        # Удаляем служебные файлы SQLite (WAL, SHM)
        for ext in ['-wal', '-shm']:
            for path in [OLD_DB_PATH + ext, NEW_DB_PATH + ext]:
                if os.path.exists(path):
                    os.remove(path)

        return True
    except Exception as e:
        print(f"   ❌ Ошибка замены: {e}")
        print(f"   ⚠️  Новая БД осталась: {NEW_DB_PATH}")
        print(f"   ⚠️  Старая БД в бэкапе")
        return False


# =====================================================================
# Main
# =====================================================================
def main():
    print("=" * 70)
    print("🔄 МИГРАЦИЯ БД GigaHash Monitor: 3.x → 4.0")
    print("=" * 70)

    # 1. Проверка старой БД
    if not os.path.exists(OLD_DB_PATH):
        print(f"❌ Старая БД не найдена: {OLD_DB_PATH}")
        return

    old_size = os.path.getsize(OLD_DB_PATH) / 1024 / 1024
    print(f"\n📁 Старая БД: {OLD_DB_PATH} ({old_size:.2f} MB)")

    # 2. Проверка схемы
    old_columns = detect_old_schema()
    if not old_columns:
        print(f"❌ Не удалось прочитать схему старой БД")
        return

    if 'balance_nicks' in old_columns:
        print(f"\n⚠️  БД уже в формате 4.0!")
        print(f"   Миграция не требуется.")
        return

    print(f"   Схема: 3.x (старая)")

    # 3. Бэкап
    print()
    backup_path = backup_db()
    if not backup_path:
        return

    # 4. Подключение к старой БД
    old_conn = sqlite3.connect(OLD_DB_PATH)

    # 5. Создание новой БД
    print()
    create_new_db()
    new_conn = sqlite3.connect(NEW_DB_PATH)

    # 6. Миграция таблиц
    try:
        migrate_miner_history(old_conn, new_conn)
        migrate_miner_versions(old_conn, new_conn)
        migrate_hourly_stats(old_conn, new_conn)
    except Exception as e:
        print(f"\n❌ ОШИБКА МИГРАЦИИ: {e}")
        import traceback
        traceback.print_exc()
        old_conn.close()
        new_conn.close()
        print(f"\n💾 Старая БД не тронута: {OLD_DB_PATH}")
        print(f"💾 Бэкап: {backup_path}")
        return

    old_conn.close()
    new_conn.close()

    # 7. Замена старой БД на новую
    if not replace_old_db():
        return

    # 8. Размеры
    new_size = os.path.getsize(OLD_DB_PATH) / 1024 / 1024

    print()
    print("=" * 70)
    print("✅ МИГРАЦИЯ ЗАВЕРШЕНА")
    print("=" * 70)
    print(f"📁 Старая БД (было): {old_size:.2f} MB")
    print(f"📁 Новая БД (стало): {new_size:.2f} MB")
    print(f"💾 Бэкап:            {backup_path}")
    print()
    print("🚀 Запусти manager.py:")
    print("   python manager.py")
    print()


if __name__ == "__main__":
    main()