# manager.py

import subprocess
import time
import os
import sys
import signal
import psutil
from datetime import datetime
import threading
import atexit
import shutil

# ===== НАСТРОЙКИ =====
SCRIPTS = {
    'monitor': 'monitor.py',
    'dashboard': 'dashboard.py',
}


# ===== МЕНЕДЖЕР ПРОЦЕССОВ =====
class ProcessManager:
    def __init__(self):
        self.processes = {}
        self.running = True
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.data_dir = os.path.join(self.script_dir, 'data')
        self.db_path = os.path.join(self.data_dir, 'history.db')
        
        atexit.register(self.cleanup)
    
    def cleanup(self):
        pass
    
    # ===== ПОИСК ПРОЦЕССОВ =====
    def find_process(self, script_name):
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                cmdline = ' '.join(proc.info['cmdline'] or [])
                if script_name in cmdline and 'python' in cmdline:
                    return proc
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return None
    
    def is_running(self, script_name):
        return self.find_process(script_name) is not None
    
    # ===== ЗАПУСК =====
    def start_process(self, name, script, args=None):
        args = args or []
        
        script_path = os.path.join(self.script_dir, script)
        
        if not os.path.exists(script_path):
            print(f"❌ Файл {script} не найден")
            return False
        
        existing = self.find_process(script)
        if existing:
            print(f"⚠️ {name} уже запущен (PID: {existing.pid})")
            return True
        
        try:
            print(f"🚀 Запуск {name}...")
            
            if sys.platform == 'win32':
                process = subprocess.Popen(
                    [sys.executable, script_path] + args,
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                    cwd=self.script_dir
                )
            else:
                process = subprocess.Popen(
                    [sys.executable, script_path] + args,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    cwd=self.script_dir,
                    start_new_session=True
                )
            
            time.sleep(2)
            
            if process.poll() is None:
                self.processes[name] = {
                    'process': process,
                    'script': script,
                    'args': args,
                    'start_time': datetime.now(),
                    'pid': process.pid
                }
                print(f"✅ {name} запущен (PID: {process.pid})")
                return True
            else:
                print(f"❌ {name} упал сразу после запуска (код: {process.returncode})")
                return False
                
        except Exception as e:
            print(f"❌ Ошибка запуска {name}: {e}")
            return False
    
    # ===== ОСТАНОВКА =====
    def stop_process(self, name, script):
        proc = self.find_process(script)
        
        if not proc:
            print(f"⚠️ {name} не запущен")
            return False
        
        try:
            print(f"🛑 Остановка {name} (PID: {proc.pid})...")
            
            try:
                proc.terminate()
                time.sleep(2)
                if proc.is_running():
                    proc.kill()
            except:
                pass
            
            if sys.platform == 'win32':
                try:
                    subprocess.run(
                        ['taskkill', '/F', '/T', '/PID', str(proc.pid)],
                        capture_output=True, timeout=5
                    )
                except:
                    pass
            
            if name in self.processes:
                del self.processes[name]
            
            print(f"✅ {name} остановлен")
            return True
            
        except Exception as e:
            print(f"❌ Ошибка остановки {name}: {e}")
            return False
    
    # ===== СТАТУС =====
    def get_status(self):
        status = {}
        for name, script in SCRIPTS.items():
            proc = self.find_process(script)
            if proc:
                try:
                    cpu = proc.cpu_percent(interval=0.1)
                    mem = proc.memory_info().rss / 1024 / 1024
                    status[name] = {
                        'running': True,
                        'pid': proc.pid,
                        'cpu': cpu,
                        'mem': round(mem, 1)
                    }
                except:
                    status[name] = {'running': True, 'pid': proc.pid, 'cpu': 0, 'mem': 0}
            else:
                status[name] = {'running': False}
        return status
    
    def print_status(self):
        status = self.get_status()
        
        print("\n" + "=" * 60)
        print("📊 СТАТУС ПРОЦЕССОВ")
        print("=" * 60)
        
        for name, script in SCRIPTS.items():
            info = status[name]
            if info['running']:
                print(f"  ✅ {name:<12} PID: {info['pid']:<8} CPU: {info['cpu']:>5.1f}%  RAM: {info['mem']:>6.1f} MB")
            else:
                print(f"  ❌ {name:<12} не запущен")
        
        print("=" * 60)
    
    # ===== ОЧИСТКА БД =====
    def clear_database(self):
        print("\n🗑️ Очистка базы данных...")
        
        if os.path.exists(self.db_path):
            try:
                size = os.path.getsize(self.db_path) / 1024
                os.remove(self.db_path)
                print(f"✅ Удален файл БД ({size:.1f} KB)")
            except Exception as e:
                print(f"❌ Ошибка удаления БД: {e}")
                return False
        else:
            print("⚠️ Файл БД не найден")
        
        return True
    
    # ===== ПЕРЕСЧЁТ СТАТИСТИКИ =====
    def recalculate_stats(self):
        print("\n🔄 Пересчёт почасовой статистики...")
        
        try:
            result = subprocess.run(
                [sys.executable, '-c', 
                 'from db import Database; db = Database(debug=True); db.recalculate_hourly()'],
                capture_output=True,
                text=True,
                cwd=self.script_dir,
                timeout=60
            )
            
            if result.returncode == 0:
                print("✅ Статистика пересчитана")
                if result.stdout:
                    print(result.stdout)
                return True
            else:
                print(f"❌ Ошибка пересчёта: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            print("❌ Таймаут пересчёта статистики")
            return False
        except Exception as e:
            print(f"❌ Ошибка пересчёта: {e}")
            return False
    
    # ===== ЗАПУСК ВСЕГО =====
    def start_all(self):
        print("\n" + "=" * 60)
        print("🚀 ЗАПУСК ВСЕХ ПРОЦЕССОВ")
        print("=" * 60)
        
        success = True
        for name, script in SCRIPTS.items():
            if not self.start_process(name, script):
                success = False
            time.sleep(2)
        
        print("=" * 60)
        if success:
            print("✅ Все процессы запущены")
        else:
            print("⚠️ Некоторые процессы не запустились")
        print(f"📊 Дашборд: http://localhost:5000")
        print("=" * 60)
    
    def stop_all(self):
        print("\n" + "=" * 60)
        print("🛑 ОСТАНОВКА ВСЕХ ПРОЦЕССОВ")
        print("=" * 60)
        
        for name, script in SCRIPTS.items():
            self.stop_process(name, script)
        
        print("=" * 60)
        print("✅ Все процессы остановлены")
        print("=" * 60)
    
    def restart_all(self):
        self.stop_all()
        time.sleep(2)
        self.start_all()


# ===== МЕНЮ =====
def show_menu():
    print("\n" + "=" * 60)
    print("⚡ GigaHash Monitor Manager")
    print("=" * 60)
    print("  1. 🚀 Запустить все процессы")
    print("  2. 🛑 Остановить все процессы")
    print("  3. 🔄 Перезапустить все процессы")
    print("  4. 📊 Статус процессов")
    print("  5. 🧹 Очистить БД и перезапустить")
    print("  6. 🔄 Пересчитать статистику")
    print("  7. ❌ Выход")
    print("=" * 60)


def main():
    try:
        import psutil
    except ImportError:
        print("❌ Не установлен psutil. Установите: pip install psutil")
        sys.exit(1)
    
    manager = ProcessManager()
    
    # ===== КОМАНДЫ ИЗ КОМАНДНОЙ СТРОКИ =====
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower()
        
        if cmd == 'start':
            manager.start_all()
            return
        elif cmd == 'stop':
            manager.stop_all()
            return
        elif cmd == 'restart':
            manager.restart_all()
            return
        elif cmd == 'status':
            manager.print_status()
            return
        elif cmd == 'clear':
            manager.stop_all()
            time.sleep(2)
            manager.clear_database()
            time.sleep(1)
            manager.start_all()
            return
        elif cmd == 'recalc':
            manager.recalculate_stats()
            return
        elif cmd in ('help', '-h', '--help'):
            print("Использование:")
            print("  python manager.py start     - запустить все")
            print("  python manager.py stop      - остановить все")
            print("  python manager.py restart   - перезапустить")
            print("  python manager.py status    - статус")
            print("  python manager.py clear     - очистить БД и запустить")
            print("  python manager.py recalc    - пересчитать статистику")
            return
        else:
            print(f"❌ Неизвестная команда: {cmd}")
            print("Используйте: python manager.py help")
            return
    
    # ===== ИНТЕРАКТИВНОЕ МЕНЮ =====
    while True:
        show_menu()
        choice = input("\nВыберите действие (1-7): ").strip()
        
        if choice == '1':
            manager.start_all()
        
        elif choice == '2':
            manager.stop_all()
        
        elif choice == '3':
            manager.restart_all()
        
        elif choice == '4':
            manager.print_status()
        
        elif choice == '5':
            print("\n⚠️ ВНИМАНИЕ: БД будет полностью удалена!")
            confirm = input("Продолжить? (y/n): ").strip().lower()
            if confirm == 'y':
                manager.stop_all()
                time.sleep(2)
                manager.clear_database()
                time.sleep(1)
                manager.start_all()
            else:
                print("Отменено")
        
        elif choice == '6':
            manager.recalculate_stats()
        
        elif choice == '7':
            print("\n👋 До свидания!")
            break
        
        else:
            print("\n❌ Неверный выбор. Попробуйте снова.")
            time.sleep(1)


if __name__ == "__main__":
    main()